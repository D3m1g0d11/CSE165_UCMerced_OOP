#include <iostream>

int main(){
    std::cout << "Hello World, my name is David Yaranon!\n";
    return EXIT_SUCCESS;
}