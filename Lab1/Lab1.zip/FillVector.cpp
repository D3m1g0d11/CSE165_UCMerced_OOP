#include <string>
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int main(){
    vector<string> v;
    ifstream in("code.cpp");
    string line, conc = "";
    while (getline(in, line)){
        v.push_back(line);
        conc = conc.append(line);
    }

    std::vector<std::string> copy = v;
    for (int i = 0; i < v.size(); i++)
        cout << i << ": " << v[i] << endl;
    
    std::cout << '\n';
    for (int i = v.size() - 1, j = 0; i >= 0, j < v.size(); i--, j++){
        cout << i << ": " << v[j] << endl;
    }

    std::cout << '\n';
    std::cout << conc;
    
}
