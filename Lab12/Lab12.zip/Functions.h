#ifndef LA12_Functions_h
#define LA12_Functions_h

#include <iostream>

namespace MyLib {
    void f(){
        std::cout << "f" << std::endl;
    }
    void g(){
        std::cout << "g" << std::endl;
    }
}


#endif