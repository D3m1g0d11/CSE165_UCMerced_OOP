#include <iostream>
#include "MoreFunctions.hpp"


using namespace MyLib;

int main(int argc, const char * argv[])
{
    f();
    someFunction();
    return 0;
}