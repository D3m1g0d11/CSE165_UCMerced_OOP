#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include "linkedlist.h"


int main(){
    LinkedList l;
    l.initialize();
    std::string line;
    std::ifstream f("input.txt");
    std::vector<double> list;
    while(std::getline(f, line)){
      list.emplace_back(std::stod(line));
    }
    for(auto &num : list){
        l.add(static_cast<void*>(&num));
    }
    LinkedList temp = l;
    while(temp.head != NULL){
        std::cout << *(double*)temp.head->data << '\n';
        temp.head = temp.head->next;
    }
    temp.cleanup();
    l.cleanup();
    
    return EXIT_SUCCESS;
}