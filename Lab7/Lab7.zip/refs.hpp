#ifndef REFS_HPP
#define REFS_HPP

void triple(int& num){
    num *= 3;
}

#endif
