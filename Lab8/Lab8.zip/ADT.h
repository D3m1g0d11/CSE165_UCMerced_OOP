#ifndef LA6_ADT_h
#define LA6_ADT_h

class ADT {
    
public:
    virtual void doSomething() = 0;
    virtual void doSomethingElse() = 0;
    virtual void dontDoThis() = 0;
};

#endif